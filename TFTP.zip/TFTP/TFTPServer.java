import java.io.*;
import java.net.*;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TFTPServer {
    private DatagramSocket socket;
    private File exampleFile;
    private ExecutorService executorService;

    public TFTPServer() {
        try {
            socket = new DatagramSocket(69); // Puerto estándar TFTP
            exampleFile = new File("example.txt");
            executorService = Executors.newFixedThreadPool(10); // Pool de 10 hilos, puedes ajustarlo según tus necesidades
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }

    public void startServer() {
        System.out.println("Servidor TFTP iniciado...");

        while (true) {
            try {
                byte[] receiveData = new byte[516]; // Tamaño máximo de un paquete TFTP
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                socket.receive(receivePacket);

                int dataLength = receivePacket.getLength();
                byte[] requestData = Arrays.copyOf(receivePacket.getData(), dataLength);

                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();

                TFTPHandler handler = new TFTPHandler(requestData, clientAddress, clientPort);
                executorService.execute(handler); // Ejecutar el handler en un hilo del pool
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    private class TFTPHandler implements Runnable {
        private byte[] requestData;
        private InetAddress clientAddress;
        private int clientPort;

        public TFTPHandler(byte[] requestData, InetAddress clientAddress, int clientPort) {
            this.requestData = requestData;
            this.clientAddress = clientAddress;
            this.clientPort = clientPort;
        }

        @Override
        public void run() {
            // Lógica para manejar las solicitudes TFTP
            try {
                // Verificar el tipo de solicitud (lectura o escritura) basado en el opcode
                if (requestData[1] == 1) { // Solicitud de lectura (RRQ)
                    handleReadRequest();
                } else if (requestData[1] == 2) { // Solicitud de escritura (WRQ)
                    handleWriteRequest();
                } else {

                    String errorMessage = "Código de operación no compatible: " + requestData[1];
                    byte[] errorData = errorMessage.getBytes();

                    DatagramPacket errorPacket = new DatagramPacket(errorData, errorData.length, clientAddress, clientPort);
                    socket.send(errorPacket);

                    System.out.println("Solicitud no compatible recibida del cliente " + clientAddress + ":" + clientPort);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        private void handleReadRequest() throws IOException {
            try (FileInputStream fileInputStream = new FileInputStream(exampleFile)) {
                byte[] fileData = new byte[(int) exampleFile.length()];
                fileInputStream.read(fileData);

                int blockNumber = 1;
                int index = 0;
                while (index < fileData.length) {
                    byte[] sendData = new byte[516];
                    sendData[0] = 0;
                    sendData[1] = 3; // Opcode de datos

                    sendData[2] = (byte) ((blockNumber >> 8) & 0xFF);
                    sendData[3] = (byte) (blockNumber & 0xFF);

                    int dataSize = Math.min(fileData.length - index, 512);
                    System.arraycopy(fileData, index, sendData, 4, dataSize);

                    DatagramPacket sendPacket = new DatagramPacket(sendData, dataSize + 4, clientAddress, clientPort);
                    socket.send(sendPacket);

                    index += 512;
                    blockNumber++;

                    // Esperar ACK del cliente después de enviar cada bloque
                    waitForACK(blockNumber, sendData);
                }
            } catch (TFTPException e) {
                throw new RuntimeException(e);
            }
        }

        class TFTPException extends Exception {
            public TFTPException(String message) {
                super(message);
            }
        }


        private void waitForACK(int expectedBlockNumber, byte[] sendData) throws IOException, TFTPException {
            boolean ackReceived = false;
            int retries = 0;

            while (!ackReceived && retries < 10) {
                byte[] receiveData = new byte[4];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

                try {
                    socket.setSoTimeout(1000);
                    socket.receive(receivePacket);

                    byte[] receivedData = receivePacket.getData();

                    if (receivedData[1] == 4) { // Opcode de ACK
                        int receivedBlockNumber = ((receivedData[2] & 0xFF) << 8) | (receivedData[3] & 0xFF);

                        if (receivedBlockNumber == expectedBlockNumber) {
                            ackReceived = true;
                        }
                    }
                } catch (SocketTimeoutException e) {
                    retries++;
                    // Reenviar el bloque de datos en caso de timeout
                    DatagramPacket resendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
                    socket.send(resendPacket);
                }
            }

            if (!ackReceived) {
                throw new TFTPException("No se recibió ACK después de reintentos");
            }
        }





        private void handleWriteRequest() throws IOException {
            FileOutputStream fileOutputStream = new FileOutputStream(exampleFile);
            boolean lastBlockReceived = false;
            int blockNumber = 0;

            while (!lastBlockReceived) {
                // Preparar el ACK para enviar al cliente
                byte[] ack = new byte[4];
                ack[0] = 0;
                ack[1] = 4; // Opcode de ACK

                DatagramPacket ackPacket = new DatagramPacket(ack, ack.length, clientAddress, clientPort);
                socket.send(ackPacket);

                byte[] receiveData = new byte[516];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                socket.receive(receivePacket);

                byte[] receivedData = receivePacket.getData();

                // Verificar si es un bloque de datos
                if (receivedData[1] == 3) { // Opcode de datos
                    int receivedBlockNumber = ((receivedData[2] & 0xFF) << 8) | (receivedData[3] & 0xFF);

                    if (receivedBlockNumber == blockNumber + 1) { // Verificar número de bloque esperado
                        int dataLength = receivePacket.getLength() - 4;
                        fileOutputStream.write(receivedData, 4, dataLength);
                        blockNumber++;

                        // Si el bloque recibido es menor que 512 bytes, es el último bloque
                        if (dataLength < 512) {
                            lastBlockReceived = true;
                        }
                    }

                    // Preparar el ACK para el número de bloque recibido
                    ack[2] = receivedData[2];
                    ack[3] = receivedData[3];
                } else {
                    // Manejar errores u opcodes no esperados
                    String errorMessage = "Opcode no esperado: " + receivedData[1];
                    byte[] errorData = errorMessage.getBytes();

                    DatagramPacket errorPacket = new DatagramPacket(errorData, errorData.length, clientAddress, clientPort);
                    socket.send(errorPacket);

                    // Opcional: registrar el error
                    System.out.println("Opcode no esperado recibido del cliente " + clientAddress + ":" + clientPort);
                }
            }

            fileOutputStream.close();
        }


    }

    public static void main(String[] args) {
        TFTPServer server = new TFTPServer();
        server.startServer();
    }
}
